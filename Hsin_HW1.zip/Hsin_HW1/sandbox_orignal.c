#include <sys/stat.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/mman.h>
#include <stdarg.h>
#include <arpa/inet.h>
#include <elf.h>

#include <stdio.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <dlfcn.h>
#include <string.h>

#define handle_error(msg)   \
    do                      \
    {                       \
        perror(msg);        \
        exit(EXIT_FAILURE); \
    } while (0)

#define errquit(m) \
    {              \
        perror(m); \
        _exit(-1); \
    }

bool is_file_blacklisted(const char *);
bool is_read_blacklisted(const char *);
bool is_connect_blacklisted(const char *, int);
bool is_addr_blacklisted(const char *);
// bool open_blacklisted(const char *, const char *);
// bool read_blacklisted(const char *, void *);
// bool connect_blacklisted(const char *, const char *, int);
// bool getaddrinfo_blacklisted(const char *, const char *);

int _open(const char *pathname, int flags, ...);
ssize_t _read(int fd, void *buf, size_t count);
ssize_t _write(int fd, const void *buf, size_t count);
int _connect(int sockfd, const struct sockaddr_in *addr, socklen_t addrlen);
int _getaddrinfo(const char *restrict node, const char *restrict service, const struct addrinfo *restrict hints, struct addrinfo **restrict res);
int _system(const char *command);

const char *global_node;
int LOGGER_FD_fd;
const unsigned long func_array[6] = {
    (unsigned long)_open, 
    (unsigned long)_read, 
    (unsigned long)_write, 
    (unsigned long)_connect, 
    (unsigned long)_getaddrinfo, 
    (unsigned long)_system};
// const void (*func_array[6])(void) = {_open, _read, _write, _connect, _getaddrinfo, _system};

// 在這個函式中，它首先從/proc/self/maps中獲取運行時程序的內存地址，然後從/proc/self/exe中讀取ELF文件，
// 查找名為.rela.plt的部分並解析它，最後執行main函式。在執行完main函式後，它會呼叫fini和rtld_fini函式，然後結束程式。

// 主要是透過自定義的 "__libc_start_main" 函式來啟動另一個 ELF 執行檔，
// 而且程式中包含了許多 Linux 內核操作所提供的函式來讀取該執行檔的記憶體、ELF 檔頭、ELF 區段表和符號表等等資訊。
int __libc_start_main(int (*main)(int, char **, char **MAIN_AUXVEC_DECL),
                      int argc, char **argv,
                      __typeof(main) init,
                      void (*fini)(void),
                      void (*rtld_fini)(void), void *stack_end)
{
    // void (*fptr)() = _open;
    // printf("%p and %p\n", fptr, _open);
    LOGGER_FD_fd = atoi(getenv("LOGGER_FD"));
    // printf("** Custom __libc_start_main() called\n");
    // get runtime program's memory address
    FILE *fp = fopen("/proc/self/maps", "r");
    if (fp == NULL)
        return 1;

    char *line = NULL;
    size_t len = 0;
    getline(&line, &len, fp);

    // 先fetch 目標command -- 子program在記憶體中的起始地址
    char cmd_base_address[13];
    strncpy(cmd_base_address, line, 12);
    cmd_base_address[12] = '\0';
    // long unsigned int cmd_base_address_long = (long unsigned int)strtol(cmd_base_address, NULL, 16);

    // while ((map_read = getline(&line, &len, fp)) != -1)
    // {
    //     fprintf(stdout, "%s", line);
    // }
    fclose(fp);
    // printf("** base = %s\n", cmd_base_address);
    // printf("** pid = %d\n", getpid());

    //------------------------------//

    // 打開 /proc/self/maps 檔案，並將檔案中的內容讀入到 buf 字符陣列中
    int fd, sz;
    // char buf[16384], buf_copy[16384], *s = buf, *token, *saveptr;
    char buf[16384], buf_copy[16384], *token, *saveptr;
    unsigned long min, max;
    if ((fd = open("/proc/self/maps", O_RDONLY)) < 0)
        errquit("get_base/open");
    if ((sz = read(fd, buf, sizeof(buf) - 1)) < 0)
        errquit("get_base/read");
    buf[sz] = '0';
    close(fd);
    strcpy(buf_copy, buf);

    // 宣告變數 base_long，用於存儲 ELF 檔的基地址
    // token = strtok_r(s, "\n\r", &saveptr);
    // s = NULL;
    token = strtok_r(buf_copy, "\n\r", &saveptr);
    unsigned long base_long = strtoul(token, NULL, 16);

    // unsigned long base_long;
    // token = strtok_r(s, "\n\r", &saveptr);
    // s = NULL;
    // sscanf(token, "%lx ", &base_long);

    // 從 buf 字符陣列中讀取每一行，並檢查是否包含 argv[0] 字符串，如果包含，則將 ELF 段的最小地址和最大地址存儲到 min 和 max 中
    // while ((token = strtok_r(s, "\n\r", &saveptr)) != NULL)
    while ((token = strtok_r(NULL, "\n\r", &saveptr)) != NULL)
    {
        // s = NULL;
        if (strstr(token, " r--p ") == NULL)
            continue;
        // if (strstr(token, argv[0]) != NULL)
        else if (strstr(token, argv[0]) != NULL)
        {
            if (sscanf(token, "%lx-%lx ", &min, &max) != 2)
                errquit("min/max fail");
        }
    }
    // 獲取系統的頁面大小
    int pagesize = sysconf(_SC_PAGE_SIZE);
    if (pagesize == -1)
        handle_error("sysconf");

    // 打開自身的 ELF 檔案，並讀取 ELF 標頭和段表頭
    // cat(), system() or any other command program's elf
    char whoelf[20];
    // sprintf(whoelf, "/usr/bin/%s", argv[0]);
    // printf("** reading %s - elf\n", whoelf);
    fp = fopen("/proc/self/exe", "rb");
    printf("** reading %s - elf\n", whoelf);
    if (!fp)
    {
        fprintf(stderr, "ERROR opening elf file\n");
        exit(-1);
    }

    Elf64_Ehdr elfHdr;
    Elf64_Shdr sectHdr;
    // elfHdr在elf的最前面
    fread(&elfHdr, sizeof(elfHdr), 1, fp);

    // 移動到 section headers table （elfHdr.e_shoff）的位置，並讀取 shstrndx 對應的 section header, 為了找到section string table的位子
    fseek(fp, elfHdr.e_shoff + elfHdr.e_shstrndx * sizeof(sectHdr), SEEK_SET);
    fread(&sectHdr, sizeof(sectHdr), 1, fp);

    // 分配一段記憶體空間用來存放 section names
    char *SectNames;
    SectNames = malloc(sectHdr.sh_size);

    // 移動到 section string table （section names)所在位置，並存取全部 section names
    fseek(fp, sectHdr.sh_offset, SEEK_SET);
    fread(SectNames, sectHdr.sh_size, 1, fp);

    // 讀取所有的 section headers，並尋找 .rela.plt section的位置
    int rela_plt_idx = 0;
    int dynsym_idx = 0;
    const char *name = "";
    for (int idx = 0; idx < elfHdr.e_shnum || (!rela_plt_idx || !dynsym_idx); idx++)
    {
        // 移動到 section headers 所在位置，並讀取該 section header
        fseek(fp, elfHdr.e_shoff + idx * sizeof(sectHdr), SEEK_SET);
        fread(&sectHdr, sizeof(sectHdr), 1, fp);

        // // 如果 section name 不為 NULL，則取出該 section name
        // if (sectHdr.sh_name)
        //     name = SectNames + sectHdr.sh_name; //地址＋索引
        name = SectNames + sectHdr.sh_name; // 地址＋索引

        // 如果 section name 為 .rela.plt，則記錄其 index
        if (!strcmp(name, ".rela.plt"))
            rela_plt_idx = idx;

        // 如果 section name 為 .dynsym，則記錄其 index
        else if (!strcmp(name, ".dynsym"))
            dynsym_idx = idx;

        // 印出 section index 和 section name
        // printf("%2u %s\n", idx, name);
    }

    // 先從section header table中找出 .dynsym's section header
    fseek(fp, elfHdr.e_shoff + dynsym_idx * sizeof(sectHdr), SEEK_SET);
    fread(&sectHdr, sizeof(sectHdr), 1, fp);

    // 分配一段記憶體空間用來存放 Elf64_Sym (都存在.dynsym section裡),
    // 其中 Elf64_Sym's st_name 是我們要的idx
    Elf64_Sym *symNamesTable;
    symNamesTable = malloc(sectHdr.sh_size);
    fseek(fp, sectHdr.sh_offset, SEEK_SET);
    fread(symNamesTable, sizeof(Elf64_Sym), sectHdr.sh_size / sizeof(Elf64_Sym), fp);

    // 再從section header table中找出 .dynstr's section header
    fseek(fp, elfHdr.e_shoff + sectHdr.sh_link * sizeof(sectHdr), SEEK_SET);
    fread(&sectHdr, sizeof(sectHdr), 1, fp);

    // 分配一段記憶體空間用來存放 symbol names string(都存在.dynstr section裡),
    // 以後用 Elf64_Sym's st_name當idx查詢
    char *strSymNames;
    strSymNames = malloc(sectHdr.sh_size);
    fseek(fp, sectHdr.sh_offset, SEEK_SET);
    fread(strSymNames, sectHdr.sh_size, 1, fp);

    // 移動到 .rela.plt 所在位置，並讀取該 section header
    fseek(fp, elfHdr.e_shoff + rela_plt_idx * sizeof(sectHdr), SEEK_SET);
    fread(&sectHdr, sizeof(sectHdr), 1, fp);
    Elf64_Rela rela;

    // Define variables to store the offsets of function symbols in the Global Offset Table (GOT)
    unsigned long func_offset[6] = {-1,-1,-1,-1,-1,-1};
    // unsigned long open_offset = -1;
    // unsigned long read_offset = -1;
    // unsigned long write_offset = -1;
    // unsigned long connect_offset = -1;
    // unsigned long getaddrinfo_offset = -1;
    // unsigned long system_offset = -1;
    unsigned long got_base_offset = 0;
    

    // Iterate through the section headers to find the symbol table
    for (int idx = 0; idx < (sectHdr.sh_size / sizeof(Elf64_Rela)); idx++)
    {
        static const char *name = "";

        // Seek to the offset of the idx-th relocation entry
        fseek(fp, sectHdr.sh_offset + idx * sizeof(Elf64_Rela), SEEK_SET);

        // Read in the relocation entry
        fread(&rela, sizeof(Elf64_Rela), 1, fp);

        // Get the name of the symbol referred to by the relocation entry
        name = strSymNames + symNamesTable[ELF64_R_SYM(rela.r_info)].st_name;
        
        if (idx == 0) {
            got_base_offset = rela.r_offset;
        }
        // Print the name of the symbol if it matches one of the functions of interest, and store its offset in the GOT
        if (!strcmp(name, "open"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // open_offset = rela.r_offset;
            func_offset[0] = rela.r_offset;
        }
        else if (!strcmp(name, "read"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // read_offset = rela.r_offset;
            func_offset[1] = rela.r_offset;
        }
        else if (!strcmp(name, "write"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // write_offset = rela.r_offset;
            func_offset[2] = rela.r_offset;
        }
        else if (!strcmp(name, "connect"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // connect_offset = rela.r_offset;
            func_offset[3] = rela.r_offset;
        }
        else if (!strcmp(name, "getaddrinfo"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // getaddrinfo_offset = rela.r_offset;
            func_offset[4] = rela.r_offset;
        }
        else if (!strcmp(name, "system"))
        {
            // printf("** FOUND %s,\toffset = %p\n", name, (void *)rela.r_offset);
            // system_offset = rela.r_offset;
            func_offset[5] = rela.r_offset;
        }
    }

    // Close the file pointer
    fclose(fp);

    // rewrite GOT

    // Calculate the number of pages covered by the loaded binary, and change their protection to read-write
    int num_of_page = (max - min) / pagesize;
    // printf("mprotect %p\n", (void *)min);
    // if (mprotect((void *)min, pagesize * num_of_page, PROT_READ | PROT_WRITE) == -1)
    if (mprotect((void *)base_long + (got_base_offset & ~(pagesize-1)), pagesize * 2, PROT_READ | PROT_WRITE) == -1)
    {
        printf("%d\n", errno);
        handle_error("mprotect");
    }

    // Define variables to hold the address of the function in the loaded binary, and its address in the GOT
    unsigned long func_address_long;
    unsigned long *f_addr;

    // If the offset for each of the functions of interest has been found,
    // overwrite their entries in the GOT with the corresponding custom functions
    // write new_func to read GOT entrys value
    for (int i = 0; i < sizeof(func_offset) / sizeof(func_offset[0]); i++)
    {
        if (func_offset[i] != -1)
        {
            func_address_long = base_long + func_offset[i];
            f_addr = (unsigned long*)func_address_long;
            *f_addr = func_array[i];
            // *f_addr = (unsigned long)func_array[i];
        }
    }

    // // write new_func to open GOT entry value
    // // if (open_offset != -1)
    // if (func_offset[0] != -1)
    // {
    //     // func_address_long = base_long + open_offset;
    //     func_address_long = base_long + func_offset[0];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_open;
    // }

    // // write new_func to read GOT entry value
    // // if (read_offset != -1)
    // if (func_offset[1] != -1)
    // {
    //     // func_address_long = base_long + read_offset;
    //     func_address_long = base_long + func_offset[1];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_read;
    // }

    // // write new_func to write GOT entry value
    // // if (write_offset != -1)
    // if (func_offset[2] != -1)
    // {
    //     // func_address_long = base_long + write_offset;
    //     func_address_long = base_long + func_offset[2];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_write;
    // }

    // // write new_func to connect GOT entry value
    // // if (connect_offset != -1)
    // if (func_offset[3] != -1)
    // {
    //     // func_address_long = base_long + connect_offset;
    //     func_address_long = base_long + func_offset[3];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_connect;
    // }

    // // write new_func to getaddrinfo GOT entry value
    // // if (getaddrinfo_offset != -1)
    // if (func_offset[4] != -1)
    // {
    //     // func_address_long = base_long + getaddrinfo_offset;
    //     func_address_long = base_long + func_offset[4];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_getaddrinfo;
    // }

    // // write new_func to system GOT entry value
    // // if (system_offset != -1)
    // if (func_offset[5] != -1)
    // {
    //     // func_address_long = base_long + system_offset;
    //     func_address_long = base_long + func_offset[5];
    //     f_addr = (long unsigned int *)func_address_long;
    //     *f_addr = (long unsigned int)_system;
    // }

    if (mprotect((void *)min, pagesize * num_of_page, PROT_READ) == -1)
    {
        printf("%d\n", errno);
        handle_error("mprotect");
    }

    // Call the real __libc_start_main()
    int (*real__libc_start_main)(int (*main)(int, char **, char **MAIN_AUXVEC_DECL),
                                 int argc, char **argv,
                                 __typeof(main) init,
                                 void (*fini)(void),
                                 void (*rtld_fini)(void), void *stack_end) = NULL;
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }
    real__libc_start_main = dlsym(handle, "__libc_start_main");
    dlclose(handle);
    return real__libc_start_main(main, argc, argv, init, fini, rtld_fini, stack_end);
}

int _open(const char *pathname, int flags, ...)
{
    mode_t mode = 0; // unsigned int
    int fd;
    // 當 open() 函式的 flags 參數設置了 O_CREAT 標誌時，代表當檔案不存在時創建一個新的檔案
    if ((flags & O_CREAT) != 0)
    {
        // 這時可以透過可變參數列表 va_list 和 va_arg 函式來獲取 mode 參數。
        // 如果未設置 O_CREAT 標誌，mode 將保持預設值 0。
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, int);
        va_end(args);
    }

    // 開檔案之前先檢查, file is blacklisted？
    // if (open_blacklisted("open", pathname))
    if (is_file_blacklisted(pathname))
    {
        errno = EACCES;
        char log_record[512];
        sprintf(log_record, "[logger] open(\"%s\", %d, %d) = %d\n", pathname, flags, mode, -1);
        write(LOGGER_FD_fd, log_record, strlen(log_record));
        // printf("[logger] open(\"%s\", %d, %d) = %d\n", pathname, flags, mode, -1);
        return -1;
    }

    // call the original open function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }

    // get original address of open
    int (*orig_open)(const char *, int, ...);
    orig_open = dlsym(handle, "open");
    if (!orig_open)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }
    fd = orig_open(pathname, flags, mode);

    char log_record[512];
    sprintf(log_record, "[logger] open(\"%s\", %d, %d) = %d\n", pathname, flags, mode, fd);
    write(LOGGER_FD_fd, log_record, strlen(log_record));
    // printf("[logger] open(\"%s\", %d, %d) = %d\n", pathname, flags, mode, fd);
    return fd;
}

ssize_t _read(int fd, void *buf, size_t count)
{
    // call the original read function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }
    // get original address of read
    ssize_t (*orig_read)(int, void *, size_t);
    orig_read = dlsym(handle, "read");
    if (!orig_read)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }

    // 先整篇讀進來判斷內容有沒有文字獄
    ssize_t st = orig_read(fd, buf, count);

    // Check if the file is blacklisted
    // if (read_blacklisted("read",  buf))
    if (is_read_blacklisted(buf))
    {
        close(fd);
        errno = EIO;
        char log_record[512];
        sprintf(log_record, "[logger] read(%d, %p, %ld) = %d\n", fd, buf, count, -1);
        // sprintf(log_record,"[logger] read(%d, %p, %ld) = -1\n", fd, buf, count);
        write(LOGGER_FD_fd, log_record, strlen(log_record));
        // pintf("[logger] read(%d, %p, %ld) = -1\n", fd, buf, count);
        return -1;
        // return EIO;
    }

    char log_record[512];
    sprintf(log_record, "[logger] read(%d, %p, %ld) = %ld\n", fd, buf, count, st);
    write(LOGGER_FD_fd, log_record, strlen(log_record));
    // printf("[logger] read(%d, %p, %ld) = %ld\n", fd, buf, count, st);

    int log_fd;
    char log_name[128];
    sprintf(log_name, "./%d-%d-read.log", getpid(), fd);
    if ((log_fd = open(log_name, O_RDWR + O_CREAT, S_IRUSR | S_IWUSR)) < 0)
        errquit("_read/open");
    write(log_fd, buf, strlen(buf));
    close(log_fd);

    return st;
}

ssize_t _write(int fd, const void *buf, size_t count)
{
    // call the original read function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }

    // get original address of write
    ssize_t (*orig_write)(int, const void *, size_t);
    orig_write = dlsym(handle, "write");
    if (!orig_write)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }

    // ssize_t st = orig_write(fd, buf, count);
    // char log_record[256];
    // sprintf(log_record, "[logger] write(%d, %p, %ld) = %ld\n", fd, buf, count, st);
    // write(LOGGER_FD_fd, log_record, strlen(log_record));
    // // printf("[logger] write(%d, %p, %ld) = %ld\n", fd, buf, count, st);

    int log_fd;
    char log_name[128];
    sprintf(log_name, "./%d-%d-write.log", getpid(), fd);
    if ((log_fd = open(log_name, O_RDWR + O_CREAT, S_IRUSR | S_IWUSR)) < 0)
        errquit("_write/open");
    write(log_fd, buf, count);
    close(log_fd);

    ssize_t st = orig_write(fd, buf, count);
    char log_record[512];
    sprintf(log_record, "[logger] write(%d, %p, %ld) = %ld\n", fd, buf, count, st);
    write(LOGGER_FD_fd, log_record, strlen(log_record));
    // printf("[logger] write(%d, %p, %ld) = %ld\n", fd, buf, count, st);

    return st;
}

int _connect(int sockfd, const struct sockaddr_in *addr, socklen_t addrlen)
{
    char ip[128];
    // 將 IPv4 或 IPv6 的二進制位址轉換成 ASCII 字串形式，存放到 ip 陣列中。
    // addr->sin_family：socket 的位址族，可能為 AF_INET 或 AF_INET6。
    // &(addr->sin_addr)：指向一個二進制的 IP 位址的指標。
    // ip：指向存放轉換後的 ASCII 字串的指標。
    // sizeof(ip)：指定緩衝區大小。
    inet_ntop(addr->sin_family, &addr->sin_addr, ip, sizeof(ip));
    // 將網路字節序（network byte order）轉換成主機字節序（host byte order），
    // 並將轉換後的值存放到 port 變數中。
    // 在這裡，addr->sin_port 是一個 16 位元的整數，代表端口號。
    int port = ntohs(addr->sin_port);

    // if (connect_blacklisted("connect", global_node, port))
    if (is_connect_blacklisted(global_node, port))
    {
        errno = ECONNREFUSED;
        char log_record[512];
        sprintf(log_record, "[logger] connect(%d, \"%s\", %d) = %d\n", sockfd, ip, addrlen, -1);
        // sprintf(log_record, "[logger] connect(%d, \"%s\", %d) = %d\n", sockfd, ip, addrlen, -1);
        write(LOGGER_FD_fd, log_record, strlen(log_record));
        // printf("[logger] connect(%d, \"%s\", %d) = %d\n", sockfd, ip, addrlen, -1);
        return -1;
        // return ECONNREFUSED;
    }

    // call the original connect function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }

    // get original address of connect
    int (*orig_connect)(int, const struct sockaddr_in *, socklen_t);
    orig_connect = dlsym(handle, "connect");
    if (!orig_connect)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }

    int ret = orig_connect(sockfd, addr, addrlen);
    char log_record[512];
    sprintf(log_record, "[logger] connect(%d, \"%s\", %d) = %d\n", sockfd, ip, addrlen, ret);
    write(LOGGER_FD_fd, log_record, strlen(log_record));
    // printf("[logger] connect(%d, \"%s\", %d) = %d\n", sockfd, ip, addrlen, ret);

    return ret;
}

int _getaddrinfo(const char *restrict node, const char *restrict service,
                 const struct addrinfo *restrict hints, struct addrinfo **restrict res)
{
    global_node = node;
    // 被blacked, 不執行原型
    //  if (getaddrinfo_blacklisted("getaddrinfo", node))
    if (is_addr_blacklisted(node))
    {
        char log_record[512];
        sprintf(log_record, "[logger] getaddrinfo(\"%s\", \"%p\", %p, %p) = %d\n", node, service, hints, res, EAI_NONAME);
        write(LOGGER_FD_fd, log_record, strlen(log_record));
        // printf("[logger] getaddrinfo(\"%s\", \"%p\", %p, %p) = %d\n", node, service, hints, res, EAI_NONAME);
        return EAI_NONAME;
    }
    // call the original getaddrinfo function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }

    // get original address of getaddrinfo
    int (*orig_getaddrinfo)(const char *restrict, const char *restrict,
                            const struct addrinfo *restrict,
                            struct addrinfo **restrict);
    orig_getaddrinfo = dlsym(handle, "getaddrinfo");
    if (!orig_getaddrinfo)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }

    // 未被blacked, 正常執行原型

    int ret = orig_getaddrinfo(node, service, hints, res);
    char log_record[512];
    sprintf(log_record, "[logger] getaddrinfo(\"%s\", \"%p\", %p, %p) = %d\n", node, service, hints, res, ret);
    write(LOGGER_FD_fd, log_record, strlen(log_record));
    // printf("[logger] getaddrinfo(\"%s\", \"%p\", %p, %p) = %d\n", node, service, hints, res, ret);
    return ret;
}

int _system(const char *command)
{
    // hijack to write the log first
    char log_record[512];
    sprintf(log_record, "[logger] system(%s)\n", command);
    write(LOGGER_FD_fd, log_record, strlen(log_record));

    // call the original connect function
    void *handle = dlopen("/usr/lib/x86_64-linux-gnu/libc.so.6", RTLD_LAZY);
    if (!handle)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        return 1;
    }
    // get original address of connect
    int (*orig_system)(const char *);
    orig_system = dlsym(handle, "system");
    if (!orig_system)
    {
        fprintf(stderr, "Error: %s\n", dlerror());
        dlclose(handle);
        return 1;
    }
    // printf("[logger] system(%s)\n", command);
    // orig_system(command);
    // return -1;
    return orig_system(command);
}

//------------------------------//
//------------------------------//
//------------------------------//
bool is_file_blacklisted(const char *pathname)
{
    const char *operation = "open";
    char line[128];
    bool in_block = false;
    bool found_pathname = false;
    const char *conf_path = getenv("SANDBOX_CONFIG");

    if (conf_path == NULL)
    {
        fprintf(stderr, "Error: environment variable SANDBOX_CONFIG not found.\n");
        return false;
    }

    FILE *fp = fopen(conf_path, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Error: failed to open config file %s.\n", conf_path);
        return false;
    }

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        if (strstr(line, "BEGIN") != NULL && strstr(line, operation) != NULL)
        {
            in_block = true;
        }
        else if (strstr(line, "END") != NULL && strstr(line, operation) != NULL)
        {
            in_block = false;
        }
        else if (in_block && strstr(line, pathname) != NULL)
        {
            found_pathname = true;
            break;
        }
    }
    fclose(fp);
    return found_pathname;
}

// bool open_blacklisted(const char *op, const char *pathname)
// {
//     struct stat buf;
//     char link_target[128];
//     char buffer[32];
//     char resolved_path[128];

//     int begin = 0;
//     int end = 0;
//     FILE *fp = fopen(getenv("SANDBOX_CONFIG"), "r");
//     // find real file
//     if (lstat(pathname, &buf) < 0)
//     {
//         perror("lstat");
//         return 1;
//     }
//     // pathname is a link 接著解析他link到的實際file, 繼續解析下去, 直到不是link為止
//     while (S_ISLNK(buf.st_mode))
//     {
//         ssize_t link_len = readlink(pathname, link_target, 128);
//         if (link_len < 0)
//         {
//             perror("readlink");
//             return 1;
//         }
//         link_target[link_len] = '\0';
//         // link to target file
//         struct stat target_buf;
//         if (stat(link_target, &target_buf) < 0)
//         {
//             perror("stat");
//             return 1;
//         }
//         // check link
//         if (S_ISREG(target_buf.st_mode))
//         {
//             pathname = link_target;
//         }
//         else if (S_ISDIR(target_buf.st_mode))
//         {
//             pathname = link_target;
//         }
//         else
//         {
//             pathname = link_target;
//         }

//         if (lstat(pathname, &buf) < 0)
//         {
//             perror("lstat");
//             return 1;
//         }
//     }

//     if (realpath(pathname, resolved_path) == NULL)
//     //用來將參數 path 所指的相對路徑轉換成絕對路徑後存於參數 resolved_pa​​th 所指的字符串數組或指針中。
//     {
//         perror("realpath");
//         return EXIT_FAILURE;
//     }

//     while (fgets(buffer, 32, fp) != NULL)
//     {

//         if (strstr(buffer, "BEGIN") != NULL)
//         {
//             if (strstr(buffer, op))
//             {
//                 begin = 1;
//             }
//             continue;
//         }
//         if (strstr(buffer, "END") != NULL)
//         {
//             if (strstr(buffer, op))
//             {
//                 end = 1;
//                 break;
//             }
//         }
//         if (begin)
//         {
//             if (strstr(buffer, resolved_path) != NULL)
//             {
//                 return true;
//             }
//         }
//     }
//     return false;
// }

bool is_read_blacklisted(const char *context)
{
    const char *operation = "read";
    char line[128];
    bool in_block = false;
    bool found_node = false;
    const char *config_path = getenv("SANDBOX_CONFIG");

    if (config_path == NULL)
    {
        fprintf(stderr, "Error: SANDBOX_CONFIG environment variable is not found.\n");
        return false;
    }

    FILE *fp = fopen(config_path, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Error: failed to open config file %s.\n", config_path);
        return false;
    }

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        if (strstr(line, "BEGIN") != NULL && strstr(line, operation) != NULL)
        {
            in_block = true;
        }
        else if (strstr(line, "END") != NULL && strstr(line, operation) != NULL)
        {
            in_block = false;
        }
        else if (in_block)
        {                                       // 如果在 BEGIN 和 END 之間
            size_t len = strcspn(line, "\r\n"); // 查找第一个换行符
            if (len > 0)
            {
                char line_tmp[128];
                strncpy(line_tmp, line, len);  // 复制子字符串
                line_tmp[len] = '\0';          // 添加字符串結束符
                if (strstr(context, line_tmp)) // 如果 line 存在於 context 中
                {
                    found_node = true;
                    break;
                }
            }
            // size_t len = strcspn(line, "\n"); // 查找第一个换行符
            // if (len > 0 && line[len - 1] == '\r')
            // { // 去掉可能存在的回车符
            //     len--;
            // }
            // strncpy(line, line, len); // 复制子字符串
            // line[len] = '\0'; // 添加字符串結束符
            // if (strstr(context, line)) // 如果 buffer 存在於 content 中
            // {
            //     found_node = true;
            //     break;
            // }
        }
        // else if (in_block && strstr(line, context) != NULL) {
        //     found_node = true;
        //     break;
        // }
    }
    fclose(fp);
    return found_node;
}

// bool read_blacklisted(const char *op, void *content)
// {
//     char buffer[32];
//     int begin = 0;
//     int end = 0;
//     FILE *fp = fopen(getenv("SANDBOX_CONFIG"), "r");

//     while (fgets(buffer, 32, fp) != NULL)
//     {
//         if (strstr(buffer, "BEGIN") != NULL)
//         {
//             if (strstr(buffer, op))
//             {
//                 begin = 1;
//                 continue;
//             }
//         }

//         if (strstr(buffer, "END") != NULL)
//         {
//             if (strstr(buffer, op))
//             {
//                 end = 1;
//                 break;
//             }
//         }

//         if (begin) // 如果在 BEGIN 和 END 之間
//         {
//             size_t len = strcspn(buffer, "\n"); // 查找第一个换行符
//             if (len > 0 && buffer[len - 1] == '\r')
//             { // 去掉可能存在的回车符
//                 len--;
//             }
//             strncpy(buffer, buffer, len); // 复制子字符串
//             buffer[len] = '\0'; // 添加字符串結束符
//             if (strstr(content, buffer)) // 如果 buffer 存在於 content 中
//             {
//                 return true; // 返回 true
//             }
//         }
//     }
//     return false;
// }

bool is_connect_blacklisted(const char *node, int port)
{
    const char *operation = "connect";
    char line[128];          // 儲存每一行讀取的文字
    char port_str[8];        // 儲存 port 的字串
    bool in_range = false;   // 標記是否在適當範圍內
    bool found_node = false; // 標記是否已經找到符合條件的節點
    const char *config_path = getenv("SANDBOX_CONFIG");

    if (config_path == NULL)
    {
        fprintf(stderr, "Error: SANDBOX_CONFIG environment variable is not found.\n");
        return false;
    }

    FILE *fp = fopen(config_path, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Error: failed to open config file %s.\n", config_path);
        return false;
    }

    // 將 port 轉成字串
    sprintf(port_str, "%d", port);

    // 逐行讀取檔案中的文字，直到讀到 EOF 結束
    while (fgets(line, sizeof(line), fp) != NULL)
    {
        // 如果這一行包含 "BEGIN" 字串，代表開始一個適當範圍的部分
        if (strstr(line, "BEGIN") != NULL && strstr(line, operation) != NULL)
        {
            in_range = true;
        }
        else if (strstr(line, "END") != NULL && strstr(line, operation) != NULL)
        {
            in_range = false;
            // if (found_node) {
            //     break;
            // }
        }
        else if (in_range && strstr(line, node) != NULL && strstr(line, port_str) != NULL)
        {
            found_node = true;
            break;
        }
    }
    fclose(fp);
    return found_node;
}

// // 檢查給定的 node 是否在 config.txt 中的黑名單列表中
// bool connect_blacklisted(const char *op, const char *node, int port)
// {
//     char buffer[32];  // 儲存每一行讀取的文字
//     char c_port[8];   // 儲存 port 的字串
//     sprintf(c_port, "%d", port);  // 將 port 轉成字串
//     int begin = 0;    // 標記是否開始了適當範圍的部分
//     int end = 0;      // 標記是否已經結束適當範圍的部分
//     FILE *fp = fopen(getenv("SANDBOX_CONFIG"), "r");
//     // FILE *fp = fopen("config.txt", "r");  // 打開 config.txt 檔案

//     // 逐行讀取檔案中的文字，直到讀到 EOF 結束
//     while (fgets(buffer, 32, fp) != NULL)
//     {
//         // 如果這一行包含 "BEGIN" 字串，代表開始一個適當範圍的部分
//         if (strstr(buffer, "BEGIN") != NULL)
//         {
//             // 如果這個範圍的名字和 op 一樣，那就開始進行判斷
//             if (strstr(buffer, op))
//             {
//                 begin = 1;
//             }
//             continue;  // 繼續進行下一行的判斷
//         }
//         // 如果這一行包含 "END" 字串，代表結束了適當範圍的部分
//         if (strstr(buffer, "END") != NULL)
//         {
//             // 如果這個範圍的名字和 op 一樣，那就結束判斷
//             if (strstr(buffer, op))
//             {
//                 end = 1;
//                 break;  // 中斷逐行讀取
//             }
//         }
//         // 如果在適當範圍內，且這一行包含給定的 node 和 port，代表有符合黑名單條件
//         if (begin)
//         {
//             if (strstr(buffer, node))
//             {
//                 if (strstr(buffer, c_port))
//                 {
//                     return true;  // 回傳符合黑名單
//                 }
//             }
//         }
//     }

//     // 若讀到 EOF 或未找到符合黑名單的條件，回傳 false
//     return false;
// }

bool is_addr_blacklisted(const char *node)
{
    // char buffer[32];
    const char *operation = "getaddrinfo";
    char line[128];
    bool in_block = false;
    bool found_node = false;
    const char *config_path = getenv("SANDBOX_CONFIG");

    if (config_path == NULL)
    {
        fprintf(stderr, "Error: SANDBOX_CONFIG environment variable is not found.\n");
        return false;
    }

    FILE *fp = fopen(config_path, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Error: failed to open config file %s.\n", config_path);
        return false;
    }

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        if (strstr(line, "BEGIN") != NULL && strstr(line, operation) != NULL)
        {
            in_block = true;
        }
        else if (strstr(line, "END") != NULL && strstr(line, operation) != NULL)
        {
            in_block = false;
            // if (found_node) {
            //     break;
            // }
        }
        else if (in_block && strstr(line, node) != NULL)
        {
            found_node = true;
            break;
        }
    }
    fclose(fp);
    return found_node;
}

// bool getaddrinfo_blacklisted(const char *op, const char *node)
// {                                   // 定義一個名為 getaddrinfo_blacklisted 的布林函式，它有兩個輸入參數，分別為 op 和 node
//     char buffer[32];                // 創建一個名為 buffer 的 char 陣列，大小為 32
//     int begin = 0;                  // 創建一個整數變量 begin，並將其設為 0
//     int end = 0;                    // 創建一個整數變量 end，並將其設為 0
//     FILE *fp = fopen(getenv("SANDBOX_CONFIG"), "r");
//     // FILE *fp = fopen("config.txt", "r");  // 創建一個指向文件的指標，並打開名為 config.txt 的文件以供讀取

//     while (fgets(buffer, 32, fp) != NULL)   // 透過 while 迴圈逐行讀取文件，直到檔案結尾
//     {
//         if (strstr(buffer, "BEGIN") != NULL)    // 如果在這行讀取到 "BEGIN"
//         {
//             if (strstr(buffer, op))             // 如果這行讀取到的內容與操作類型相符
//             {
//                 begin = 1;                      // 設定 begin 為 1
//             }
//             continue;                           // 跳過這行讀取
//         }
//         if (strstr(buffer, "END") != NULL)      // 如果在這行讀取到 "END"
//         {
//             if (strstr(buffer, op))             // 如果這行讀取到的內容與操作類型相符
//             {
//                 end = 1;                        // 設定 end 為 1
//                 break;                          // 跳出 while 迴圈
//             }
//         }
//         if (begin)                              // 如果 begin 為真
//         {
//             if (strstr(buffer, node))           // 如果這行讀取到的內容與節點相符
//             {
//                 return true;                    // 回傳 true
//             }
//         }
//     }
//     return false;                               // 回傳 false
// }